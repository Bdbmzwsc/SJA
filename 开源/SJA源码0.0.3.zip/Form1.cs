﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
//中途加入
using System.IO;
using System.IO.Compression;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace SJA分析器_C_
{
    public partial class Form1 : Form
    {
        public string jsonstr;
        public int timee;
        public Single dashu;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
              //  string jsonstr;
              //   jsonstr = textBox1.Text;
              //   MessageBox.Show(jsonstr);
                  int tt=0;
                  int canlookt = 0;
            //string[] temp = Regex.Split(jsonstr, "blocks");
            string[] temp;
            int ii = jsonstr.IndexOf("blocks");
            string ss = jsonstr.Substring(ii + 6);
                  //MessageBox.Show(temp[1]);
                  temp = Regex.Split(ss, "comments");
                  string str = temp[0].Replace("opcode", "");
                   int count = temp[0].Length - str.Length;
                    count = count / 6;
                  //  MessageBox.Show(count.ToString());
                     for (int j = 1; j <= count; j++)
                   {
                        if (tt != 0)
                    {

                          int i = temp[0].IndexOf("shadow",tt+4);
                         tt = i;
                        //  MessageBox.Show(i.ToString());
           //  MessageBox.Show(temp[0].Substring(i+8,1));
                        if (temp[0].Substring(i + 8, 1) == "f")
                          {
                             canlookt += 1;
                         }
                         else
                        {
                             canlookt += 0;
                        }
            
                    }
                  else
                  {
                                int i = temp[0].IndexOf("shadow");
                                tt = i;
           //  MessageBox.Show(temp[0].Substring(i + 8, 1));
                            }
                    }
                       label1.Text = "有效积木:" + canlookt + "\r\n合计:" + count;


          //  DataTable dt = new DataTable();
          //  string json = JsonConvert.SerializeObject(dt);
          //  dt = JsonConvert.DeserializeObject<DataTable>(jsonstr);
          //  foreach (DataRow dr in dt.Rows)
          //  {
          //      MessageBox.Show(dr[0].ToString());
           // }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chu();
            //jsonstr = textBox1.Text;
           // button3.PerformClick();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Isok = InitialDialog("选择您的sb3文件");
            if (Isok == "0")
            {
                MessageBox.Show("无法选择文件," + Isok);
                return;
            }
            label2.Text = "正在解析此sb3文件";
           // MessageBox.Show("正在解析");
            try
            {
                string FilezipPath = AppDomain.CurrentDomain.BaseDirectory + @"Plugin\temp\001.zip";
                System.IO.File.Copy(Isok, FilezipPath, true);
                string zipFile = FilezipPath;
                ZipFile.ExtractToDirectory(FilezipPath, AppDomain.CurrentDomain.BaseDirectory + @"Plugin\temp\001");
                label2.Text = "上传成功";
                button1.Enabled = true;

                using (StreamReader sr = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"Plugin\temp\001\project.json"))
                {
                    string line;

                    // 从文件读取并显示行，直到文件的末尾 
                    while ((line = sr.ReadLine()) != null)
                    {
                        jsonstr = line;
                        textBox1.Text = line;
                    }

                }
                string[] ttem = textBox1.Text.Split(":".ToCharArray());

 
            }
            catch (Exception ex)
            {
                MessageBox.Show("出错：" + ex.Message);
            }
        }
        private string InitialDialog( string title)
        {
            openFileDialog1.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;//初始化路径
            openFileDialog1.Filter = "sb3 files (*.sb3,*.*)|*.sb3;*.*";//过滤选项设置，文本文件，所有文件。
            openFileDialog1.FilterIndex = 1;//当前使用第二个过滤字符串
            openFileDialog1.RestoreDirectory = true;//对话框关闭时恢复原目录
            openFileDialog1.Title = title;
            try
            {
                openFileDialog1.ShowDialog();
                return openFileDialog1.FileName;

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
                
            
        }
        public class Targets
        {
            // public class blocks
            //  {
            public string opcode;
            public string next;
            public string parent;
            public string inputs;
            public string fields;
            public string shadow;
            public string topLevel;
            public string blocks;

         //   }
       //  public string blocks { get; set; }
        }
        public class cancaojimu {
            public List<Targets> targets { get; set; }

        }
        public void chu()
        {
           
            
                DirectoryInfo dir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory + @"Plugin\temp");
                if (dir.Exists)
                {
                    DirectoryInfo[] childs = dir.GetDirectories();
                    foreach (DirectoryInfo child in childs)
                    {
                        child.Delete(true);
                    }
                    dir.Delete(true);
                
                }
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + @"Plugin\temp");
        }
        public class wendaModel
        {
            private string _title;
            private string _cons;

            public string title
            {
                set { _title = value; }
                get { return _title; }
            }
            public string cons
            {
                set { _cons = value; }
                get { return _cons; }
            }
        }
                  public static string MidStrEx(string sourse, string startstr, string endstr)
          {
              string result = string.Empty;
              int startindex, endindex;
              try
            {
                  startindex = sourse.IndexOf(startstr);
                 if (startindex == -1)
                      return result;
                 string tmpstr = sourse.Substring(startindex + startstr.Length);
                 endindex = tmpstr.IndexOf(endstr);           
                 if (endindex == -1)
                     return result;
                 result = tmpstr.Remove(endindex);
             }
             catch (Exception ex)
             {
                MessageBox.Show(ex.Message);
             }
             return result;
         }

        private void button3_Click(object sender, EventArgs e)
        {
          //  string jsonstr = textBox1.Text;
          //  JArray jarry = JArray.Parse("[" + jsonstr + "]");
          //  string a = jarry[0]["blocks"]["shadow"].ToString();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
    
          //  tabControl1.SelectedIndex = 1;
           // timer1.Enabled = true;
           // timee = 0;
            //label3.Text = "0";
            JObject _jObject = JObject.Parse(jsonstr);
         //   JObject job;
            JArray ja;
           // JArray jarr;
            int canlookt = 0;
            int zong = 0;
            int eventshu = 0;
            var t = _jObject["targets"].ToString();
            ja = JArray.Parse(t);
            for (int i = 0; i <= ja.Count - 1; i++)
            {
                t = ja[i].ToString();
                _jObject = JObject.Parse(t);
                foreach (JProperty item in _jObject["blocks"].Children())
              {

                   
                    
                    // t = _jObject["blocks"][item.Name].ToString();
                    if (_jObject["blocks"][item.Name]["shadow"].ToString() == "False")
                    {
                        canlookt += 1;
                        zong += 1;
                    }
                    else
                    {
                        zong += 1;
                    }
                    //JObject jar;
                    foreach (JProperty tt in _jObject["blocks"][item.Name]["inputs"].Children())
                    {
                        JArray jar = JArray.Parse(tt.Value.ToString());//遍历inputs
                        
                       
                            // foreach (JProperty ttt in jar.Children())
                            //{
                            // JArray jjar = JArray.Parse(ttt.Value.ToString());
                         //   listBox1.Items.Add(jar[1].ToString());
                        if (jar[1].ToString().Length > 20)
                        {
                            //  JObject jobbb = JObject.Parse(jar[1].ToString());
                            JArray jobbb = JArray.Parse(jar[1].ToString());
                            if (jobbb[0].ToString() == "12" | jobbb[0].ToString() =="13")
                            {
                                canlookt += 1;
                                zong += 1;
                                dashu += 1;
                            }
                            
                        }
                        //    if (jar[1].ToString().Length)


                        //    JObject jobbb = JObject.Parse(jar[1].ToString());
                     //       for (int iii = 0; iii <= jobbb.Count - 1; iii++)
                    //    {
                             
                    //    }
                          //  if (jar[1].ToString() == "12" || jar[1].ToString() == "13")
                            //    {
                                    //  MessageBox.Show(jjar[0].ToString());
                                //    canlookt += 1;
                              //  }

                            //}
                        
                    }


                    //     foreach (JProperty t1 in _jObject["blocks"][item.Name]["inputs"].Children())
                    //     {
                    //          JArray jar;
                    //         jar = JArray.Parse(t1.Value.ToString());
                    //         for (int i2 = 0; i2 <= jar.Count - 1; i2++)
                    //         {
                    //               if (jar[i2].ToString() == "a")
                    //                     {

                    //                    }
                    //                 }
                    //
                    //              }
                    //________________________________________________________
                    // foreach (JProperty t1 in _jObject["blocks"][item.Name]["inputs"].Children())
                    //  {


                    // }


                }
               

            }

            // Application.DoEvents();

            //   foreach (JProperty item in _jObject.Children())
            //  {
            //      MessageBox.Show(item.Name + "---" + item.Value + item + "\r\n");
            //   }
            evertv(canlookt);
            role.Text = "角色数量\r\n" + (ja.Count-1).ToString();
            label1.Text = "有效积木:" + canlookt + "\r\n合计:" + zong;
           // MessageBox.Show(_jObject["blocks"]["shadow"].ToString());
            /**************************************/

            //_jObject = JObject.Parse("{ID:{ID1:{ID2:'value',name:'valueName'}},'Name':'test','Mark':'Hello Word'}");

            //  label1.Text = "有效积木:" + canlookt + "\r\n合计:" + t6;
            tabControl1.SelectedIndex = 1;
        }
        static void tick(object ob)

        {
        

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timee += 1;
            label3.Text = timee.ToString();
          //  MessageBox.Show(timee.ToString());
            //Application.DoEvents();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("a");
        }
        public void evertv(Single zz)
        {
            JArray ja;
            JObject _jObject = JObject.Parse(jsonstr);
            Single eventshu = 0;
            Single looksshu = 0;
            Single motionshu = 0;
            Single Soundshu = 0;
            Single controlshu = 0;
            Single sensingshu = 0;
            Single operatershu = 0;
            var t = _jObject["targets"].ToString();
            ja = JArray.Parse(t);
            for (int i = 0; i <= ja.Count - 1; i++)
            {
                t = ja[i].ToString();
                _jObject = JObject.Parse(t);
                foreach (JProperty item in _jObject["blocks"].Children())
                {
                    JObject jar = JObject.Parse(item.Value.ToString());
                    string[] temp = jar["opcode"].ToString().Split("_".ToCharArray());
                    //______________________事件_____________________________
                    if (temp[0] == "event")
                    {
                        //listBox1.Items.Add(jar["shadow"].ToString());
                      //  eventshu += 1;
                      if (jar["shadow"].ToString() != "True")
                        {
                            listBox1.Items.Add(jar["shadow"].ToString());
                              eventshu += 1;
                        }
                    }
                    //__________外观_______________________________
                    if (temp[0] == "looks")
                    {
                       
                        if (jar["shadow"].ToString() != "True")
                        {
                           // listBox1.Items.Add(jar["shadow"].ToString());
                            looksshu += 1;
                        }
                    }
                    //______________________运动__________________________
                    if (temp[0] == "motion")
                    {

                        if (jar["shadow"].ToString() != "True")
                        {
                           // listBox1.Items.Add(jar["shadow"].ToString());
                            motionshu += 1;
                        }
                    }
                    //________________________声音______________________
                    if (temp[0] == "sound")
                    {

                        if (jar["shadow"].ToString() != "True")
                        {
                            // listBox1.Items.Add(jar["shadow"].ToString());
                            Soundshu += 1;
                        }
                    }
                    //__________________________控制________________________
                    if (temp[0] == "control")
                    {

                        if (jar["shadow"].ToString() != "True")
                        {
                            // listBox1.Items.Add(jar["shadow"].ToString());
                            controlshu += 1;
                        }
                    }
                    //___________________侦测_____________
                    if (temp[0] == "sensing")
                    {

                        if (jar["shadow"].ToString() != "True")
                        {
                            // listBox1.Items.Add(jar["shadow"].ToString());
                            sensingshu += 1;
                        }
                    }
                    //_________________运算_____________________
                    if (temp[0] == "operator")
                    {

                        if (jar["shadow"].ToString() != "True")
                        {
                            // listBox1.Items.Add(jar["shadow"].ToString());
                            operatershu += 1;
                        }
                    }
                    if (temp[0] == "data")
                    {

                        if (jar["shadow"].ToString() != "True")
                        {
                            // listBox1.Items.Add(jar["shadow"].ToString());
                            dashu += 1;
                        }
                    }
                }
            //    MessageBox.Show(zz.ToString());
            //    MessageBox.Show(eventshu.ToString());
                Event.Text = eventshu.ToString() + " 事件:" + (eventshu / zz * 100).ToString() + "%";
                looks.Text = looksshu.ToString() + " 外观:" + (looksshu / zz * 100).ToString() + "%";
                motion.Text = motionshu.ToString() + " 运动:" + (motionshu / zz * 100).ToString() + "%";
                Sounds.Text = Soundshu.ToString() + " 声音:" + (Soundshu / zz * 100).ToString() + "%";
                control.Text = controlshu.ToString() + " 控制:" + (controlshu / zz * 100).ToString() + "%";
               sensing.Text = sensingshu.ToString() + " 侦测:" + (sensingshu / zz * 100).ToString() + "%";
                opera.Text = operatershu .ToString() + " 运算:" + (operatershu / zz * 100).ToString() + "%";
                data.Text = dashu.ToString() + " 变量+列表:" + (dashu / zz * 100).ToString() + "%";
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
