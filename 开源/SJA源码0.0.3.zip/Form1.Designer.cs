﻿
namespace SJA分析器_C_
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Sounds = new System.Windows.Forms.Label();
            this.motion = new System.Windows.Forms.Label();
            this.looks = new System.Windows.Forms.Label();
            this.Event = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.role = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.titlee = new System.Windows.Forms.Label();
            this.control = new System.Windows.Forms.Label();
            this.sensing = new System.Windows.Forms.Label();
            this.opera = new System.Windows.Forms.Label();
            this.data = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(689, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 63);
            this.button1.TabIndex = 0;
            this.button1.Text = "解析json";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(187, 110);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(165, 66);
            this.button2.TabIndex = 3;
            this.button2.Text = "上传文件";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(184, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "所有积木";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(370, 113);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(170, 63);
            this.button3.TabIndex = 5;
            this.button3.Text = "解析json";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(497, 448);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "所有积木";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(-1, -22);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(937, 537);
            this.tabControl1.TabIndex = 7;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(929, 511);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(924, 257);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(89, 28);
            this.listBox1.TabIndex = 7;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(924, 222);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(49, 63);
            this.button4.TabIndex = 6;
            this.button4.Text = "解析json";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(187, 83);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(455, 21);
            this.textBox1.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.data);
            this.tabPage2.Controls.Add(this.opera);
            this.tabPage2.Controls.Add(this.sensing);
            this.tabPage2.Controls.Add(this.control);
            this.tabPage2.Controls.Add(this.Sounds);
            this.tabPage2.Controls.Add(this.motion);
            this.tabPage2.Controls.Add(this.looks);
            this.tabPage2.Controls.Add(this.Event);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.titlee);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(918, 489);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // Sounds
            // 
            this.Sounds.AutoSize = true;
            this.Sounds.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Sounds.ForeColor = System.Drawing.Color.Black;
            this.Sounds.Location = new System.Drawing.Point(53, 314);
            this.Sounds.Name = "Sounds";
            this.Sounds.Size = new System.Drawing.Size(49, 20);
            this.Sounds.TabIndex = 6;
            this.Sounds.Text = "声音";
            // 
            // motion
            // 
            this.motion.AutoSize = true;
            this.motion.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.motion.ForeColor = System.Drawing.Color.Black;
            this.motion.Location = new System.Drawing.Point(53, 231);
            this.motion.Name = "motion";
            this.motion.Size = new System.Drawing.Size(49, 20);
            this.motion.TabIndex = 5;
            this.motion.Text = "运动";
            // 
            // looks
            // 
            this.looks.AutoSize = true;
            this.looks.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.looks.ForeColor = System.Drawing.Color.Black;
            this.looks.Location = new System.Drawing.Point(53, 275);
            this.looks.Name = "looks";
            this.looks.Size = new System.Drawing.Size(49, 20);
            this.looks.TabIndex = 4;
            this.looks.Text = "外观";
            // 
            // Event
            // 
            this.Event.AutoSize = true;
            this.Event.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Event.ForeColor = System.Drawing.Color.Black;
            this.Event.Location = new System.Drawing.Point(53, 351);
            this.Event.Name = "Event";
            this.Event.Size = new System.Drawing.Size(49, 20);
            this.Event.TabIndex = 3;
            this.Event.Text = "事件";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.role);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(6, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(906, 147);
            this.panel1.TabIndex = 2;
            // 
            // role
            // 
            this.role.AutoSize = true;
            this.role.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.role.ForeColor = System.Drawing.Color.Black;
            this.role.Location = new System.Drawing.Point(3, 0);
            this.role.Name = "role";
            this.role.Size = new System.Drawing.Size(69, 20);
            this.role.TabIndex = 2;
            this.role.Text = "角色：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(220, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "积木块数";
            // 
            // titlee
            // 
            this.titlee.AutoSize = true;
            this.titlee.Font = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.titlee.Location = new System.Drawing.Point(279, 5);
            this.titlee.Name = "titlee";
            this.titlee.Size = new System.Drawing.Size(209, 35);
            this.titlee.TabIndex = 0;
            this.titlee.Text = "SJA解析报告";
            // 
            // control
            // 
            this.control.AutoSize = true;
            this.control.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.control.ForeColor = System.Drawing.Color.Black;
            this.control.Location = new System.Drawing.Point(540, 231);
            this.control.Name = "control";
            this.control.Size = new System.Drawing.Size(49, 20);
            this.control.TabIndex = 7;
            this.control.Text = "控制";
            // 
            // sensing
            // 
            this.sensing.AutoSize = true;
            this.sensing.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.sensing.ForeColor = System.Drawing.Color.Black;
            this.sensing.Location = new System.Drawing.Point(540, 275);
            this.sensing.Name = "sensing";
            this.sensing.Size = new System.Drawing.Size(49, 20);
            this.sensing.TabIndex = 8;
            this.sensing.Text = "侦测";
            // 
            // opera
            // 
            this.opera.AutoSize = true;
            this.opera.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.opera.ForeColor = System.Drawing.Color.Black;
            this.opera.Location = new System.Drawing.Point(540, 314);
            this.opera.Name = "opera";
            this.opera.Size = new System.Drawing.Size(49, 20);
            this.opera.TabIndex = 9;
            this.opera.Text = "运算";
            // 
            // data
            // 
            this.data.AutoSize = true;
            this.data.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.data.ForeColor = System.Drawing.Color.Black;
            this.data.Location = new System.Drawing.Point(540, 351);
            this.data.Name = "data";
            this.data.Size = new System.Drawing.Size(49, 20);
            this.data.TabIndex = 10;
            this.data.Text = "变量";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 517);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label titlee;
        private System.Windows.Forms.Label role;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label Event;
        private System.Windows.Forms.Label looks;
        private System.Windows.Forms.Label motion;
        private System.Windows.Forms.Label Sounds;
        private System.Windows.Forms.Label data;
        private System.Windows.Forms.Label opera;
        private System.Windows.Forms.Label sensing;
        private System.Windows.Forms.Label control;
    }
}

